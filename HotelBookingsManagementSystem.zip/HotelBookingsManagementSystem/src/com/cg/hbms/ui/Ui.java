package com.cg.hbms.ui;

import java.util.Scanner;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;
import com.cg.hbms.service.Validation;
import com.cg.hbms.service.ValidationImpl;

public class Ui {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String mainOption;
		char mainChoice='y';
		
		System.out.println("----------------WELCOME TO HBMS----------------");
		
		
		while(mainChoice=='y')
		{
			System.out.println("\n1. Login as Customer"
					+ "\n2. Login as Hotel Employee"
					+ "\n3. Login as Admin"
					+ "\n4. New user? Register"
					+ "\n5. Exit"
					+ "\n\nSelect option: ");
			mainOption=sc.nextLine();
			switch(mainOption)
			{
			case "1":
				System.out.println("User Login coming soon...");
				break;
				
				
			case "2":
				System.out.println("Hotel Employee Login coming soon...");
				break;
				
				
			case "3":
				char adminLoginChoice='y';
				AdminService adminService= new AdminServiceImpl();
				Validation adminValidate=new ValidationImpl();
				while(adminLoginChoice=='y')
				{
					
					System.out.println("Enter Admin User ID: ");
					String strAdminId =sc.nextLine();
					System.out.println("Enter Admin password: ");
					String adminPassword=sc.nextLine();
					
					boolean isValidLoginCredentials = adminService.authenticate(strAdminId,adminPassword);
					if(isValidLoginCredentials)
					{
						System.out.println("Login Successful");
						String adminOption;
						char adminChoice='y';
						System.out.println("\n-----WELCOME ADMIN-----\nPlease select on option:\n");
						while(adminChoice=='y')
						{
							System.out.println("1. Add Hotel\n"
									+ "2. Delete Hotel\n"
									+ "3. Add Room\n"
									+ "4. Delete Room\n"
									+ "5. View List of Hotels\n"
									+ "6. View Bookings for a spcific hotel\n"
									+ "7. View Bookings of a specific date\n"
									+ "8. Back to Home Page\n"
									+ "9. Exit"
									+ "\nEnter choice (1-9) : ");
							adminOption = sc.nextLine();
							String strHotelId=null;
							String hotelName=null;
							String hotelCity=null;
							String hotelAddress=null;
							String hotelDescription=null;
							String strHotelAvgRatePerNight=null;
							String hotelPhone1=null;
							String hotelPhone2=null;
							String strHotelRating=null;
							String hotelEmail=null;
							String roomType=null;
							String strPerNightRate=null;
							String roomNo=null;
							String strDate=null;
							boolean isValidInput;
							switch(adminOption){
							case "1":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel Name : ");
									hotelName=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelName);
									if(hotelName.length()>20 || !isValidInput)
									{
										System.out.println("Hotel Name can only contain alphabets, digits & spaces...(Max Length = 20)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter City : ");
									hotelCity=sc.nextLine();
									isValidInput=adminValidate.isValidAlphabeticInput(hotelCity);
									if(hotelCity.length()>10 || !isValidInput)
									{
										System.out.println("City Name can only contain alphabets...(Max Allowed Length = 10)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel Address : ");
									hotelAddress=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelAddress);
									if(hotelAddress.length()>25 || !isValidInput)
									{
										System.out.println("Hotel Address can only contain alphabets, Digits and spaces...(Max Allowed Length = 25)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Discription : ");
									hotelDescription=sc.nextLine();
									isValidInput=adminValidate.isValidAlphanumericInput(hotelDescription);
									if(hotelDescription.length()>50 || !isValidInput)
									{
										System.out.println("Descrition can only contain alphabtes, digits and spaces...(Max Allowed Length=50)\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Average Rate per night : ");
									strHotelAvgRatePerNight=sc.nextLine();
									isValidInput=adminValidate.isValidAmount(strHotelAvgRatePerNight);
									if(!isValidInput)
									{
										System.out.println("Please Enter a Numerical value...\n");	
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Phone Number : ");
									hotelPhone1=sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(hotelPhone1);
									if(hotelPhone1.length()!=10 || !isValidInput)
									{
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Alternate Phone Number : ");
									hotelPhone2=sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(hotelPhone2);
									if(hotelPhone1.length()!=10 || !isValidInput)
									{
										System.out.println(isValidInput);
										System.out.println("Invalid Phone Number...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Rating (out of 5): ");
									strHotelRating=sc.nextLine();
									isValidInput=adminValidate.isValidRating(strHotelRating);
									if(!isValidInput)
									{
										System.out.println("Please Enter a decimal value between 0 to 5...\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Hotel Email ID : ");
									hotelEmail=sc.nextLine();
									isValidInput=adminValidate.isValidEmailId(hotelEmail);
									if(!isValidInput)
									{
										System.out.println("Invalid Email address...\n");
									}
								}
								System.out.println(adminService.addHotel(hotelName, hotelCity, hotelAddress, hotelDescription, strHotelAvgRatePerNight, hotelPhone1, hotelPhone2, strHotelRating, hotelEmail));
								break;
								
							case "2":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								System.out.println(adminService.delHotel(strHotelId));
								sc.nextLine();
								break;
								
							case "3":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Room Number");
									roomNo=sc.nextLine();
									isValidInput=adminValidate.isValidRoomNumber(roomNo);
									if(!isValidInput)
									{
										System.out.println("Room Number can only contain Alphabets & Digits...\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Room Type (Ac / NonAc) : ");
									roomType = sc.nextLine();
									if(!(roomType.equals("Ac") || roomType.equals("NonAc")))
									{
										System.out.println("Please Enter a Valid Room Type...(Ac / NonAc)\n");
									}
								}
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Rate per night : ");
									strPerNightRate = sc.nextLine();
									isValidInput=adminValidate.isValidAmount(strPerNightRate);
									if(!isValidInput)
									{
										System.out.println("Please Enter a Numerical value...\n");
									}
								}
								System.out.println(adminService.addRoom(strHotelId,roomNo,roomType,strPerNightRate));
								break;
								
							case "4":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								System.out.println(adminService.delRoom(strHotelId));
								break;
							case "5":
								System.out.println("***List of Hotels***\n"+adminService.viewListOfHotels());
								break;
							case "6":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Hotel ID : ");
									strHotelId = sc.nextLine();
									isValidInput=adminValidate.isValidNumericInput(strHotelId);
									if(strHotelId.length()!=3 || !isValidInput)
									{
										System.out.println("Hotel ID can only be numeric 3 digit value...\n");
										isValidInput=false;
									}
								}
								if(adminService.viewBookingsByHotel(strHotelId).isEmpty())
								{
									System.out.println("No bookings found for given Hotel ID "+strHotelId);
								}
								else
								{
									System.out.println("Bookings for Hotel ID: "+strHotelId);
									System.out.println(adminService.viewBookingsByHotel(strHotelId));
								}
								break;
							case "7":
								isValidInput=false;
								while(!isValidInput)
								{
									System.out.println("Enter Date (yyyy-mm-dd) : ");
									strDate = sc.nextLine();
									isValidInput=adminValidate.isValidDate(strDate);
									if(!isValidInput)
									{
										System.out.println("Invalid Date. Check Input Format!!..\n");
									}
								}
								if(adminService.viewBookingsByDate(strDate).isEmpty())
								{
									System.out.println("No Bookings found for given Date "+strDate+"\n");
								}
								else
								{
									System.out.println("Bookings for Date "+strDate);
									System.out.println(adminService.viewBookingsByDate(strDate)+"\n");
								}
								break;
								
							case "8":
								adminChoice='n';
								adminLoginChoice='n';
								break;
							case "9":
								adminChoice='n';
								adminLoginChoice='n';
								mainChoice='n';
								System.out.println("Thank you for using HBMS");
								break;
							default :
								System.out.println("\nInvalid Selection!..Select Again\n");
								break;
						}
					}
				}
				else
				{
					System.out.println("Invalid Login Credentials!..\n");
					System.out.println("\nPress 0 to Go back to home page"
							+ "\nPress any other digit to try again..."
							+ "\n\nSelect option");
					int tryLogin = sc.nextInt();
					sc.nextLine();
					if(tryLogin==0)
					{
						adminLoginChoice='n';
					}
				}
				}
				break;
			case "4":
				System.out.println("Registeration page coming soon...");
				break;
			case "5":
				System.out.println("Thank you for using HBMS!!");
				mainChoice='n';
				break;
			default:
				System.out.println("Invalid Selection!! Select Again\n");
				break;
			}
		}
		
	}

}
